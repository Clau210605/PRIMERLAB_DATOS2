package Events;

public interface AVLTreeEvents {

    /**
     * Called when the tree is modified.
     */
    void treeModified();

}
