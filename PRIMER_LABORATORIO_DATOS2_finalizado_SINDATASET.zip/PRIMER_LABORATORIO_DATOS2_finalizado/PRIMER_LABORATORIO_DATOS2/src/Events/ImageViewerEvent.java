package Events;

import java.io.File;

public interface ImageViewerEvent {

    void imageClicked(File file, File folder);

}
