package Events;

import Models.AVLNode;

import java.util.ArrayList;

public interface TreeDrawerEvent<T> {

    /**
     * Called a node is clicked / selected.
     * @param selectedNode The node that was clicked.
     * @param nodeIndex The index of the node that was clicked.
     */
    void nodeSelected(AVLNode<T> selectedNode, int nodeIndex);

    /**
     * Called when a node is unselected.
     */
    void nodeUnselected();

}
