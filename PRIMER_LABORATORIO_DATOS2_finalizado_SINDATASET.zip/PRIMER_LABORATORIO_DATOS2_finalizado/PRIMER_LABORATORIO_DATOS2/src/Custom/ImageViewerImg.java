package Custom;

import Events.ImageViewerEvent;
import java.awt.Color;
import java.io.File;
import javax.swing.ImageIcon;

public class ImageViewerImg extends PanelRound {

    private ImageViewerEvent event; // Evento asociado al visor de imágenes
    private File file; // Archivo de imagen actual
    private File folderFile; // Carpeta que contiene la imagen

    // Método para obtener el evento del visor de imágenes
    public ImageViewerEvent getEvent() {
        return event;
    }

    // Método para establecer el evento del visor de imágenes
    public void setEvent(ImageViewerEvent event) {
        this.event = event;
    }

    // Constructor de la clase ImageViewerImg
    public ImageViewerImg(File folderFile, File file) {
        initComponents(); // Inicializa los componentes de la clase base

        folder.setText(folderFile.getName()); // Establece el nombre de la carpeta
        title.setText(file.getName()); // Establece el nombre del archivo
        image.setIcon(new ImageIcon(file.getAbsolutePath())); // Establece la imagen

        this.file = file; // Establece el archivo de imagen actual
        this.folderFile = folderFile; // Establece la carpeta que contiene la imagen
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        folder = new javax.swing.JLabel();
        title = new javax.swing.JLabel();
        image = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        folder.setFont(new java.awt.Font("Montserrat ExtraBold", 0, 11)); // NOI18N
        folder.setForeground(new java.awt.Color(51, 51, 51));
        folder.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        folder.setText("jLabel1");
        add(folder, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 210, 20));

        title.setFont(new java.awt.Font("Montserrat ExtraLight", 0, 16)); // NOI18N
        title.setForeground(new java.awt.Color(51, 51, 51));
        title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        title.setText("jLabel1");
        add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 210, 40));
        add(image, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 210, 120));
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
        setBackground(new Color(204, 204, 204));
    }//GEN-LAST:event_formMouseEntered

    private void formMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseExited
        setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_formMouseExited

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
    }//GEN-LAST:event_formMousePressed

    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
        setBackground(new Color(153, 153, 153));
        event.imageClicked(file, folderFile);
    }//GEN-LAST:event_formMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel folder;
    private javax.swing.JLabel image;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables
}
