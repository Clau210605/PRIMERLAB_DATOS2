package Custom;

import Events.TreeDrawerEvent; // Importa la clase TreeDrawerEvent del paquete Events.
import Models.AVLNode; // Importa la clase AVLNode del paquete Models.
import Models.AVLTree; // Importa la clase AVLTree del paquete Models.

import javax.swing.*; // Importa las clases del paquete javax.swing.
import java.awt.*; // Importa las clases del paquete java.awt.
import java.awt.event.MouseAdapter; // Importa la clase MouseAdapter del paquete java.awt.event.
import java.awt.event.MouseEvent; // Importa la clase MouseEvent del paquete java.awt.event.
import java.awt.event.MouseWheelEvent; // Importa la clase MouseWheelEvent del paquete java.awt.event.
import java.awt.geom.Ellipse2D; // Importa la clase Ellipse2D del paquete java.awt.geom.
import java.awt.geom.Line2D; // Importa la clase Line2D del paquete java.awt.geom.
import java.util.ArrayList; // Importa la clase ArrayList del paquete java.util.
import java.util.Collections; // Importa la clase Collections del paquete java.util.
import java.util.function.Function; // Importa la clase Function del paquete java.util.function.

/**
 * La clase TreeDrawer representa un panel para dibujar un árbol AVL.
 *
 * @param <T> El tipo de datos que contiene el árbol AVL.
 */
public class TreeDrawer<T> extends JPanel {

    private AVLTree<T> tree; // Representa el árbol AVL que se dibujará.
    private TreeDrawerEvent<T> events; // Representa los eventos relacionados con el dibujo del árbol.
    private double zoom = 1; // Representa el nivel de zoom del dibujo del árbol.
    private int panelX = 0; // Representa la posición horizontal del panel de dibujo.
    private int panelY = 0; // Representa la posición vertical del panel de dibujo.
    private double metric = 50; // Representa la métrica utilizada para calcular las posiciones de los nodos.
    private double nodeSize = 30; // Representa el tamaño predeterminado de los nodos del árbol.
    private ArrayList<Ellipse2D> nodesList = new ArrayList<>(); // Lista que contiene las formas elípticas para representar los nodos del árbol.
    private ArrayList<AVLNode<T>> nodesInfoList = new ArrayList<>(); // Lista que contiene la información de los nodos del árbol.
    private ArrayList<Line2D> connectionsList = new ArrayList<>(); // Lista que contiene las líneas que conectan los nodos del árbol.
    private Ellipse2D selectedShape = null; // Representa la forma seleccionada en el dibujo del árbol.
    private Function<T, String> show = Object::toString; // Función utilizada para mostrar la información de los nodos.
    private final RenderingHints hints; // Representa las sugerencias de renderizado para el dibujo del árbol.
    private Color nodeColor = new Color(0, 0, 0); // Representa el color predeterminado de los nodos del árbol.
    private int lastX = 0; // Representa la última posición horizontal del mouse.
    private int lastY = 0; // Representa la última posición vertical del mouse.

    /**
     * Constructor de la clase TreeDrawer. Configura las sugerencias de
     * renderizado y agrega un MouseListener para manejar eventos de mouse.
     */
    public TreeDrawer() {
        // Configuración de las sugerencias de renderizado para mejorar la calidad gráfica
        hints = new RenderingHints(RenderingHints.KEY_ALPHA_INTERPOLATION,
                RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        hints.put(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_COLOR_RENDERING,
                RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        hints.put(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        hints.put(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);

        // Agrega un MouseListener para manejar eventos de mouse
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Calcula las coordenadas reales considerando el zoom y la posición del panel
                double realX = (e.getX() / zoom) - panelX;
                double realY = (e.getY() / zoom) - panelY;

                boolean clicked = false;
                selectedShape = null;
                // Verifica si se ha hecho clic en alguna forma elíptica que representa un nodo
                for (Ellipse2D shape : nodesList) {
                    if (shape.contains(realX, realY)) {
                        selectedShape = shape;
                        clicked = true;
                        break;
                    }
                }

                // Si no se hizo clic en ningún nodo, se deselecciona el nodo y se notifica al evento correspondiente
                if (!clicked) {
                    selectedShape = null;
                    events.nodeUnselected();
                } else {
                    // Si se hizo clic en un nodo, se selecciona y se notifica al evento correspondiente
                    events.nodeSelected(nodesInfoList.get(nodesList.indexOf(selectedShape)), nodesList.indexOf(selectedShape));
                }

                // Se repinta el panel para reflejar los cambios
                repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // Registra la posición del mouse al presionarlo
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        // Agrega un MouseMotionListener para manejar eventos de arrastre del mouse
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                // Actualiza la posición del panel de acuerdo al movimiento del mouse
                panelX += (e.getX() - lastX) / zoom;
                panelY += (e.getY() - lastY) / zoom;
                lastX = e.getX();
                lastY = e.getY();
                repaint(); // Vuelve a pintar el panel para reflejar los cambios
            }
        });

        // Agrega un MouseWheelListener para manejar eventos de rueda del mouse
        addMouseWheelListener(new MouseAdapter() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                // Calcula el cambio de zoom según el movimiento de la rueda del mouse
                double delta = 0.05 * e.getPreciseWheelRotation();
                zoom -= delta;
                zoom = Math.max(0.1, zoom); // Limita el zoom mínimo
                repaint(); // Vuelve a pintar el panel para reflejar los cambios
            }
        });
    }

    /**
     * Método para calcular las formas (nodos y conexiones) a dibujar en el
     * panel.
     */
    public void calculateShapes() {
        // Limpia las listas de nodos y conexiones
        nodesList.clear();
        connectionsList.clear();

        // Verifica si el árbol está nulo, en caso afirmativo, retorna
        if (tree == null) {
            return;
        }

        int maxLevel = tree.getMaxLevel();
        ArrayList<Double> centerSizes = new ArrayList<>();
        ArrayList<Double> sideSizes = new ArrayList<>();

        // Calcula el tamaño de los centros y los lados de cada nivel del árbol
        for (int i = 0; i <= maxLevel; i++) {
            centerSizes.add(metric * Math.pow(2, i));
            if (i == 0) {
                sideSizes.add(0.0);
            } else if (i == 1) {
                sideSizes.add(metric / 2);
            } else {
                sideSizes.add(sideSizes.get(sideSizes.size() - 1) + centerSizes.get(centerSizes.size() - 2) / 2);
            }
        }

        // Invierte las listas de tamaños de centro y lado
        Collections.reverse(centerSizes);
        Collections.reverse(sideSizes);

        // Inicializa arreglos para los nodos de cada nivel y las conexiones entre ellos
        AVLNode<T>[] levelNodes = new AVLNode[]{tree.getRoot()};
        Ellipse2D[] connections = new Ellipse2D[]{null};
        boolean first = true;

        // Itera mientras haya tamaños de centro disponibles
        while (centerSizes.size() > 0) {
            // Obtiene el tamaño del centro y del lado para el nivel actual
            double centerSize = centerSizes.remove(0);
            double sideSize = sideSizes.remove(0);

            // Arreglo para almacenar las formas de los nodos del nivel actual
            Ellipse2D[] actualLevelShapes = new Ellipse2D[levelNodes.length];

            // Itera sobre los nodos del nivel actual
            for (int i = 0; i < levelNodes.length; i++) {
                AVLNode<T> node = levelNodes[i];
                if (node == null) {
                    continue;
                }

                // Calcula la posición del nodo en el panel
                double x = sideSize + centerSize * i;
                double y = centerSize * -1;

                // Establece la posición inicial del panel en caso de ser el primer nodo a dibujar
                if (first) {
                    panelX = (int) (-x) + 250;
                    panelY = (int) (-y) + 150;
                    first = false;
                }

                // Agrega la forma del nodo a la lista de nodos y la información del nodo a la lista correspondiente
                nodesList.add(new Ellipse2D.Double(x, y, nodeSize, nodeSize));
                nodesInfoList.add(node);
                actualLevelShapes[i] = new Ellipse2D.Double(x, y, nodeSize, nodeSize);

                // Agrega la conexión entre el nodo actual y su nodo padre (si existe)
                if (connections[i] != null) {
                    connectionsList.add(new Line2D.Double(x + nodeSize / 2, y + 3,
                            connections[i].getX() + nodeSize / 2, connections[i].getY() + nodeSize - 3));
                }
            }

            // Arreglos para almacenar los nodos del siguiente nivel y las conexiones entre ellos
            AVLNode<T>[] newLevelNodes = new AVLNode[levelNodes.length * 2];
            Ellipse2D[] newConnections = new Ellipse2D[levelNodes.length * 2];

            // Itera sobre los nodos del nivel actual para obtener los nodos del siguiente nivel y las conexiones
            for (int i = 0; i < levelNodes.length; i++) {
                AVLNode<T> node = levelNodes[i];
                if (node == null) {
                    continue;
                }

                // Agrega los hijos del nodo actual y las conexiones entre ellos
                newLevelNodes[i * 2] = node.getLeft();
                newLevelNodes[i * 2 + 1] = node.getRight();
                newConnections[i * 2] = actualLevelShapes[i];
                newConnections[i * 2 + 1] = actualLevelShapes[i];
            }

            // Actualiza los arreglos de nodos del nivel actual y conexiones para el siguiente nivel
            levelNodes = newLevelNodes;
            connections = newConnections;
        }
    }

    /**
     * Obtiene el árbol que se está representando en el panel.
     *
     * @return El árbol AVL representado en el panel.
     */
    public AVLTree<T> getTree() {
        return tree;
    }

    /**
     * Establece el árbol que se debe representar en el panel.
     *
     * @param tree El árbol AVL que se va a representar.
     */
    public void setTree(AVLTree<T> tree) {
        this.tree = tree;
        calculateShapes(); // Calcula las formas de los nodos y conexiones para el nuevo árbol
    }

    /**
     * Obtiene el nivel de zoom actual del panel.
     *
     * @return El nivel de zoom actual.
     */
    public double getZoom() {
        return zoom;
    }

    /**
     * Establece el nivel de zoom del panel.
     *
     * @param zoom El nuevo nivel de zoom.
     */
    public void setZoom(double zoom) {
        this.zoom = zoom;
    }

    /**
     * Obtiene la métrica utilizada para dibujar el árbol.
     *
     * @return La métrica utilizada.
     */
    public double getMetric() {
        return metric;
    }

    /**
     * Obtiene el tamaño de los nodos del árbol.
     *
     * @return El tamaño de los nodos.
     */
    public double getNodeSize() {
        return nodeSize;
    }

    /**
     * Obtiene la función utilizada para mostrar la información de los nodos.
     *
     * @return La función para mostrar la información de los nodos.
     */
    public Function<T, String> getShow() {
        return show;
    }

    /**
     * Establece la función utilizada para mostrar la información de los nodos.
     *
     * @param show La función para mostrar la información de los nodos.
     */
    public void setShow(Function<T, String> show) {
        this.show = show;
        repaint(); // Vuelve a pintar el panel para reflejar los cambios
    }

    /**
     * Obtiene la posición actual del panel en el eje X.
     *
     * @return La posición actual del panel en el eje X.
     */
    public int getPanelX() {
        return panelX;
    }

    /**
     * Establece la posición del panel en el eje X.
     *
     * @param panelX La nueva posición del panel en el eje X.
     */
    public void setPanelX(int panelX) {
        this.panelX = panelX;
        repaint(); // Vuelve a pintar el panel para reflejar los cambios
    }

    /**
     * Obtiene el objeto que maneja los eventos relacionados con el dibujo del
     * árbol.
     *
     * @return El objeto que maneja los eventos del árbol.
     */
    public TreeDrawerEvent<T> getEvents() {
        return events;
    }

    /**
     * Establece el objeto que maneja los eventos relacionados con el dibujo del
     * árbol.
     *
     * @param events El objeto que maneja los eventos del árbol.
     */
    public void setEvents(TreeDrawerEvent<T> events) {
        this.events = events;
    }

    /**
     * Establece la métrica utilizada para dibujar el árbol.
     *
     * @param metric La nueva métrica.
     */
    public void setMetric(double metric) {
        this.metric = metric;
    }

    /**
     * Establece el tamaño de los nodos del árbol.
     *
     * @param nodeSize El nuevo tamaño de los nodos.
     */
    public void setNodeSize(double nodeSize) {
        this.nodeSize = nodeSize;
    }

    /**
     * Obtiene la posición actual del panel en el eje Y.
     *
     * @return La posición actual del panel en el eje Y.
     */
    public int getPanelY() {
        return panelY;
    }

    /**
     * Establece la posición del panel en el eje Y.
     *
     * @param panelY La nueva posición del panel en el eje Y.
     */
    public void setPanelY(int panelY) {
        this.panelY = panelY;
        repaint();
    }

    /**
     * Obtiene el color de los nodos del árbol.
     *
     * @return El color de los nodos.
     */
    public Color getNodeColor() {
        return nodeColor;
    }

    /**
     * Establece el color de los nodos del árbol.
     *
     * @param nodeColor El nuevo color de los nodos.
     */
    public void setNodeColor(Color nodeColor) {
        this.nodeColor = nodeColor;
    }

    /**
     * Obtiene el nodo seleccionado actualmente en el panel.
     *
     * @return El nodo seleccionado.
     */
    public AVLNode<T> getSelected() {
        if (selectedShape == null) {
            return null;
        }
        return nodesInfoList.get(nodesList.indexOf(selectedShape));
    }

    /**
     * Establece el nodo seleccionado en el panel.
     *
     * @param node El nodo que se desea seleccionar.
     */
    public void setSelected(AVLNode<T> node) {
        for (int i = 0; i < nodesInfoList.size(); i++) {
            if (node.equals(nodesInfoList.get(i))) {
                selectedShape = nodesList.get(i);
                break;
            }
        }

        if (selectedShape != null) {
            zoom = 1; // Restablece el nivel de zoom a 1 para mostrar solo el nodo seleccionado
            panelX = (int) (-selectedShape.getX()) + 250; // Calcula la posición X del panel para centrar el nodo seleccionado en X
            panelY = (int) (-selectedShape.getY()) + 150; // Calcula la posición Y del panel para centrar el nodo seleccionado en Y
            repaint(); // Vuelve a pintar el componente para reflejar los cambios

            // Notifica a los escuchadores del evento que se ha seleccionado un nodo
            events.nodeSelected(node, nodesList.indexOf(selectedShape));
        }

    }

    // Método para mostrar un nodo específico en el panel
    public void showNode(AVLNode<T> node) {
        // Itera sobre la lista de información de nodos para encontrar el nodo especificado
        for (int i = 0; i < nodesInfoList.size(); i++) {
            // Comprueba si el nodo actual coincide con el nodo especificado
            if (node.equals(nodesInfoList.get(i))) {
                zoom = 1; // Restablece el nivel de zoom a 1 para mostrar solo el nodo especificado
                panelX = (int) (-nodesList.get(i).getX()) + 250; // Calcula la posición X del panel para centrar el nodo especificado en X
                panelY = (int) (-nodesList.get(i).getY()) + 150; // Calcula la posición Y del panel para centrar el nodo especificado en Y
                repaint(); // Vuelve a pintar el componente para reflejar los cambios
                break; // Sale del bucle una vez que se encuentra el nodo especificado
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Llama al método paintComponent de la clase base para realizar la limpieza del área de dibujo

        Graphics2D g2 = (Graphics2D) g; // Convierte el objeto Graphics en Graphics2D para habilitar características avanzadas de dibujo
        g2.addRenderingHints(hints); // Agrega sugerencias de renderizado para mejorar la calidad del dibujo

        g2.scale(zoom, zoom); // Escala el sistema de coordenadas según el nivel de zoom actual
        g2.translate(panelX, panelY); // Translada el origen del sistema de coordenadas según la posición del panel

        g2.setColor(nodeColor.brighter()); // Establece el color para dibujar las conexiones entre los nodos, usando un tono más claro del color de los nodos
        g2.setStroke(new BasicStroke(5)); // Establece el grosor de la línea para dibujar las conexiones

        // Dibuja las conexiones entre los nodos como líneas
        for (Line2D line : connectionsList) {
            g2.draw(line);
        }

        g2.setColor(nodeColor); // Restablece el color al color original de los nodos

        // Dibuja cada nodo como un óvalo
        for (int i = 0; i < nodesList.size(); i++) {
            Ellipse2D shape = nodesList.get(i); // Obtiene la forma del nodo actual

            if (selectedShape != null) {
                if (selectedShape.equals(shape)) {
                    g2.setColor(new Color(132, 66, 221)); // Si el nodo actual es el nodo seleccionado, establece un color de resaltado
                    // Dibuja un óvalo más grande alrededor del nodo seleccionado para resaltarlo
                    Ellipse2D borderShape = new Ellipse2D.Double(shape.getX() - 3, shape.getY() - 3, shape.getWidth() + 6, shape.getHeight() + 6);
                    g2.fill(borderShape); // Rellena el óvalo de resaltado
                }
                g2.setColor(nodeColor); // Restablece el color al color original de los nodos
            } else {
                g2.setColor(nodeColor); // Establece el color de los nodos
            }

            g2.fill(shape); // Rellena el nodo actual con el color establecido

            g2.setColor(getForeground()); // Establece el color del texto como el color del primer plano del componente
            g2.setFont(getFont()); // Establece la fuente de texto del componente

            // Centra el texto dentro del nodo y lo dibuja
            String text = centerText(show.apply(nodesInfoList.get(i).getData()), (int) shape.getWidth());
            g2.drawString(text, (int) (shape.getX()),
                    (int) (shape.getY() + shape.getHeight() / 2 + getFontMetrics(getFont()).getHeight() / 4));
        }
    }

// Método privado para centrar el texto dentro del nodo
    private String centerText(String text, int width) {
        int textLength = getFontMetrics(getFont()).stringWidth(text); // Calcula la longitud del texto en píxeles
        int spaceLength = getFontMetrics(getFont()).stringWidth(" "); // Calcula la longitud de un espacio en píxeles

        int spaces = (width - textLength) / spaceLength / 2; // Calcula la cantidad de espacios necesarios para centrar el texto
        for (int i = 0; i < spaces; i++) {
            text = " " + text + " "; // Añade espacios antes y después del texto para centrarlo
        }

        return text; // Retorna el texto centrado
    }

}
