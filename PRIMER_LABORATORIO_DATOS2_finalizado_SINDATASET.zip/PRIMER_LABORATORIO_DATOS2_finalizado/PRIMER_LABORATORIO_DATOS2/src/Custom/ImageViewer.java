package Custom;

import Events.ImageViewerEvent;
import java.io.File;
import javax.swing.JPanel;

public class ImageViewer extends JPanel {

    private ImageViewerEvent events; // Evento asociado al visor de imágenes

    // Método para obtener el evento del visor de imágenes
    public ImageViewerEvent getEvents() {
        return events;
    }

    // Método para establecer el evento del visor de imágenes
    public void setEvents(ImageViewerEvent events) {
        this.events = events;
    }

    // Constructor de la clase ImageViewer
    public ImageViewer() {
        setLayout(new WrapLayout()); // Establece un layout de flujo envolvente para los componentes
    }

    // Método para agregar un archivo al visor de imágenes
    public void addFile(File file, File folder) {
        ImageViewerImg newFile = new ImageViewerImg(folder, file); // Crea un nuevo componente ImageViewerImg
        // Asigna un evento al nuevo componente que se activa cuando se hace clic en la imagen
        newFile.setEvent((file1, folder1) -> events.imageClicked(file1, folder1));
        add(newFile); // Agrega el nuevo componente al panel
    }

}
