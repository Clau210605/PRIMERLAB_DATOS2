package Custom;

import javax.swing.*;
import java.awt.*;

// Clase que extiende JTabbedPane para personalizar su apariencia
public class CustomTabbedPane extends JTabbedPane {

    // Constructor de la clase
    public CustomTabbedPane() {
        // Elimina el borde predeterminado del JTabbedPane
        setBorder(null);
        // Establece el color de fondo del JTabbedPane como transparente
        setBackground(new Color(0, 0, 0, 0));
        // Establece el color de primer plano del JTabbedPane como transparente
        setForeground(new Color(0, 0, 0, 0));
        // Establece una IU personalizada para el JTabbedPane para modificar su apariencia
        setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            // Sobreescribe el método para calcular la altura de las pestañas
            @Override
            protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
                return 0; // Retorna 0 para eliminar la altura de las pestañas
            }

            // Sobreescribe el método para pintar el borde del contenido
            @Override
            protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
                // No dibuja ningún borde alrededor de las pestañas
            }

            // Sobreescribe el método para pintar el área de las pestañas
            @Override
            protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex) {
                // No dibuja el área de las pestañas
            }
        });
    }

    // Método para agregar una pestaña al JTabbedPane
    public void addTab(String title, Component component) {
        super.addTab(null, component); // Llama al método addTab de la clase base con un título nulo
    }
}
