package Custom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ImageButton extends JButton {

    enum State {
        NORMAL, HOVER, PRESSED
    }

    private Icon image; // Icono normal del botón
    private Icon imageOver; // Icono cuando el mouse está sobre el botón
    private Icon imagePressed; // Icono cuando se presiona el botón
    private State state = State.NORMAL; // Estado actual del botón
    private boolean enableHeigth = true; // Bandera para habilitar el ajuste de altura
    private boolean over; // Bandera para indicar si el mouse está sobre el botón
    private RenderingHints hints; // Hints para la renderización

    // Método para obtener el icono normal del botón
    public Icon getImage() {
        return image;
    }

    // Método para establecer el icono normal del botón
    public void setImage(Icon image) {
        this.image = image;
        repaint(); // Vuelve a pintar el botón
    }

    // Método para obtener el icono cuando el mouse está sobre el botón
    public Icon getImageOver() {
        return imageOver;
    }

    // Método para establecer el icono cuando el mouse está sobre el botón
    public void setImageOver(Icon imageOver) {
        this.imageOver = imageOver;
    }

    // Método para obtener el icono cuando el botón está presionado
    public Icon getImagePressed() {
        return imagePressed;
    }

    // Método para establecer el icono cuando el botón está presionado
    public void setImagePressed(Icon imagePressed) {
        this.imagePressed = imagePressed;
    }

    // Método para verificar si se habilita el ajuste de altura
    public boolean isEnableHeigth() {
        return enableHeigth;
    }

    // Método para establecer si se habilita el ajuste de altura
    public void setEnableHeigth(boolean enableHeigth) {
        this.enableHeigth = enableHeigth;
        repaint(); // Vuelve a pintar el botón
    }

    // Constructor de la clase ImageButton
    public ImageButton() {
        // Configuración del botón
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setOpaque(false);

        setBackground(new Color(0, 0, 0, 0));
        setForeground(new Color(0, 0, 0, 0));
        hints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        hints.put(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        hints.put(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        hints.put(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);

        // Agrega oyentes de eventos de mouse
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me) {
                state = State.HOVER;
                over = true;
                repaint(); // Vuelve a pintar el botón
            }

            @Override
            public void mouseExited(MouseEvent me) {
                state = State.NORMAL;
                over = false;
                repaint(); // Vuelve a pintar el botón
            }

            @Override
            public void mousePressed(MouseEvent me) {
                state = State.PRESSED;
                repaint(); // Vuelve a pintar el botón
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                if (over) {
                    state = State.HOVER;
                } else {
                    state = State.NORMAL;
                }
                repaint(); // Vuelve a pintar el botón
            }
        });
    }

    // Método que sobreescribe la pintura del componente
    @Override
    protected void paintComponent(Graphics grphcs) {
        Graphics2D g2d = (Graphics2D) grphcs.create();
        g2d.setRenderingHints(hints);

        setText(""); // Establece el texto del botón como vacío para que no se muestre ningún texto

        // Determina qué imagen dibujar según el estado del botón
        if (state == State.NORMAL) {
            drawImage(g2d, image); // Dibuja la imagen normal
        } else if (state == State.HOVER) {
            drawImage(g2d, imageOver); // Dibuja la imagen cuando el mouse está sobre el botón
        } else if (state == State.PRESSED) {
            drawImage(g2d, imagePressed); // Dibuja la imagen cuando el botón está presionado
        }

        // Rellena el área del botón con un color transparente
        g2d.setColor(new Color(0, 0, 0, 0));
        g2d.fillRect(0, 0, getWidth(), getHeight());

        g2d.dispose(); // Libera los recursos de Graphics2D
        super.paintComponent(grphcs); // Llama al método paintComponent de la clase base para completar la pintura
    }

    // Método para establecer los límites del botón
    @Override
    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x, y, width, height); // Llama al método setBounds de la clase base para establecer los límites
    }

    // Método para dibujar la imagen en el botón
    private void drawImage(Graphics grphcs, Icon image) {
        if (image != null) {
            if (enableHeigth) {
                // Calcula la nueva altura proporcionalmente al ancho del botón
                double newHeight = ((double) image.getIconHeight() * (double) getWidth()) / (double) image.getIconWidth();
                grphcs.drawImage(((ImageIcon) image).getImage(), 0, 0, getWidth(), (int) newHeight, null);
            } else {
                // Calcula el nuevo ancho proporcionalmente a la altura del botón
                double newWidth = ((double) image.getIconWidth() * (double) getHeight()) / (double) image.getIconHeight();
                grphcs.drawImage(((ImageIcon) image).getImage(), 0, 0, (int) newWidth, getHeight(), null);
            }
        }
    }

}
