package Custom;

import javax.swing.*; // Importa las clases del paquete javax.swing para construir la interfaz gráfica
import java.awt.*; // Importa las clases del paquete java.awt para manejar la interfaz de usuario y los gráficos
import java.awt.geom.Area; // Importa la clase Area del paquete java.awt.geom para manipular áreas geométricas
import java.awt.geom.Rectangle2D; // Importa la clase Rectangle2D del paquete java.awt.geom para crear un rectángulo con coordenadas de punto flotante
import java.awt.geom.RoundRectangle2D; // Importa la clase RoundRectangle2D del paquete java.awt.geom para crear un rectángulo con esquinas redondeadas

public class PanelRound extends JPanel { // Declaración de la clase PanelRound que extiende JPanel

    // Métodos getters y setters para los atributos de redondeo
    // Obtiene el valor del redondeo superior izquierdo
    public int getRoundTopLeft() {
        return roundTopLeft;
    }

    // Establece el valor del redondeo superior izquierdo y repinta el panel
    public void setRoundTopLeft(int roundTopLeft) {
        this.roundTopLeft = roundTopLeft;
        repaint();
    }

    // Obtiene el valor del redondeo superior derecho
    public int getRoundTopRight() {
        return roundTopRight;
    }

    // Establece el valor del redondeo superior derecho y repinta el panel
    public void setRoundTopRight(int roundTopRight) {
        this.roundTopRight = roundTopRight;
        repaint();
    }

    // Obtiene el valor del redondeo inferior izquierdo
    public int getRoundBottomLeft() {
        return roundBottomLeft;
    }

    // Establece el valor del redondeo inferior izquierdo y repinta el panel
    public void setRoundBottomLeft(int roundBottomLeft) {
        this.roundBottomLeft = roundBottomLeft;
        repaint();
    }

    // Métodos getters y setters para los atributos restantes
    // Obtiene el valor del redondeo inferior derecho
    public int getRoundBottomRight() {
        return roundBottomRight;
    }

    // Establece el valor del redondeo inferior derecho y repinta el panel
    public void setRoundBottomRight(int roundBottomRight) {
        this.roundBottomRight = roundBottomRight;
        repaint();
    }

    // Obtiene el estado de la personalización del rectángulo
    public boolean isEnableCustomRectangle() {
        return enableCustomRectangle;
    }

    // Establece el estado de la personalización del rectángulo y repinta el panel
    public void setEnableCustomRectangle(boolean enableCustomRectangle) {
        this.enableCustomRectangle = enableCustomRectangle;
        repaint();
    }

    // Obtiene el valor del radio de redondeo
    public int getRadius() {
        return radius;
    }

    // Establece el valor del radio de redondeo y repinta el panel
    public void setRadius(int radius) {
        this.radius = radius;
        repaint();
    }

    // Atributos privados de la clase
    private int radius = 30; // Radio predeterminado del redondeo
    private int roundTopLeft = 0; // Redondeo superior izquierdo
    private int roundTopRight = 0; // Redondeo superior derecho
    private int roundBottomLeft = 0; // Redondeo inferior izquierdo
    private int roundBottomRight = 0; // Redondeo inferior derecho
    private boolean enableCustomRectangle; // Estado de la personalización del rectángulo

    // Constructor de la clase PanelRound
    public PanelRound() {
        setOpaque(false); // Establece el panel como no opaco
    }

    // Método para dibujar el componente
    @Override
    protected void paintComponent(Graphics grphcs) {
        // Crea un nuevo contexto gráfico
        Graphics2D g2 = (Graphics2D) grphcs.create();
        // Establece la configuración de renderizado para suavizar los bordes
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Establece el color de fondo del componente
        g2.setColor(getBackground());
        Area area;
        // Si se habilita la personalización del rectángulo, crea un área personalizada; de lo contrario, crea un área con esquinas redondeadas
        if (enableCustomRectangle) {
            area = createCustomRectangle(getWidth(), getHeight());
        } else {
            area = new Area(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), radius, radius));
        }
        // Rellena el área con el color de fondo
        g2.fill(area);

        // Libera los recursos del contexto gráfico
        g2.dispose();
        // Llama al método paintComponent de la clase padre
        super.paintComponent(grphcs);
    }

    // Método para crear un área personalizada para el rectángulo
    private Area createCustomRectangle(int width, int height) {
        // Crea un área con la esquina superior izquierda redondeada
        Area area = new Area(createRoundTopLeft(width, height));
        // Si el redondeo superior derecho es mayor que cero, interseca el área con una nueva área que tiene la esquina superior derecha redondeada
        if (roundTopRight > 0) {
            area.intersect(new Area(createRoundTopRight(width, height)));
        }
        // Si el redondeo inferior izquierdo es mayor que cero, interseca el área con una nueva área que tiene la esquina inferior izquierda redondeada
        if (roundBottomLeft > 0) {
            area.intersect(new Area(createRoundBottomLeft(width, height)));
        }
        // Si el redondeo inferior derecho es mayor que cero, interseca el área con una nueva área que tiene la esquina inferior derecha redondeada
        if (roundBottomRight > 0) {
            area.intersect(new Area(createRoundBottomRight(width, height)));
        }
        return area;
    }

    // Método para crear un área con la esquina superior izquierda redondeada
    private Shape createRoundTopLeft(int width, int height) {
        // Calcula el tamaño del redondeo en el eje X y en el eje Y
        int roundX = Math.min(width, roundTopLeft);
        int roundY = Math.min(height, roundTopLeft);
        // Crea un área con la esquina superior izquierda redondeada
        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        // Agrega un área que representa el borde derecho del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(roundX / 2, 0, width - roundX / 2, height)));
        // Agrega un área que representa el borde inferior del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(0, roundY / 2, width, height - roundY / 2)));
        return area;
    }

    // Método para crear un área con la esquina superior derecha redondeada
    private Shape createRoundTopRight(int width, int height) {
        // Calcula el tamaño del redondeo en el eje X y en el eje Y
        int roundX = Math.min(width, roundTopRight);
        int roundY = Math.min(height, roundTopRight);
        // Crea un área con la esquina superior derecha redondeada
        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        // Agrega un área que representa el borde izquierdo del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(0, 0, width - roundX / 2, height)));
        // Agrega un área que representa el borde inferior del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(0, roundY / 2, width, height - roundY / 2)));
        return area;
    }

    // Método para crear un área con la esquina inferior izquierda redondeada
    private Shape createRoundBottomLeft(int width, int height) {
        // Calcula el tamaño del redondeo en el eje X y en el eje Y
        int roundX = Math.min(width, roundBottomLeft);
        int roundY = Math.min(height, roundBottomLeft);
        // Crea un área con la esquina inferior izquierda redondeada
        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        // Agrega un área que representa el borde derecho del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(roundX / 2, 0, width - roundX / 2, height)));
        // Agrega un área que representa el borde superior del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(0, 0, width, height - roundY / 2)));
        return area;
    }

    // Método para crear un área con la esquina inferior derecha redondeada
    private Shape createRoundBottomRight(int width, int height) {
        // Calcula el tamaño del redondeo en el eje X y en el eje Y
        int roundX = Math.min(width, roundBottomRight);
        int roundY = Math.min(height, roundBottomRight);
        // Crea un área con la esquina inferior derecha redondeada
        Area area = new Area(new RoundRectangle2D.Double(0, 0, width, height, roundX, roundY));
        // Agrega un área que representa el borde izquierdo del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(0, 0, width - roundX / 2, height)));
        // Agrega un área que representa el borde superior del rectángulo redondeado
        area.add(new Area(new Rectangle2D.Double(0, 0, width, height - roundY / 2)));
        return area;
    }
}
