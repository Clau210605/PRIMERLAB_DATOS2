package Custom;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LogoLabel extends JLabel {

    // Atributo para almacenar la imagen del JLabel
    private Icon image;
    // Atributo para habilitar/deshabilitar el ajuste de la altura de la imagen
    private boolean enableHeight = true;
    // Atributo para habilitar/deshabilitar el centrado de la imagen
    private boolean enableCentered = false;
    // Objeto para configurar las propiedades de renderizado
    private RenderingHints rh;

    // Constructor de la clase LogoLabel
    public LogoLabel() {
        // Inicializa las propiedades de renderizado
        rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        rh.put(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        rh.put(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        rh.put(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
    }

    // Método getter para obtener la imagen del JLabel
    public Icon getImage() {
        return image;
    }

    // Método setter para establecer la imagen del JLabel
    public void setImage(Icon image) {
        this.image = image;
        repaint();
    }

    // Método getter para obtener el estado del ajuste de la altura
    public boolean isEnableHeight() {
        return enableHeight;
    }

    // Método setter para habilitar/deshabilitar el ajuste de la altura
    public void setEnableHeight(boolean enableHeight) {
        this.enableHeight = enableHeight;
        repaint();
    }

    // Método getter para obtener el estado del centrado de la imagen
    public boolean isEnableCentered() {
        return enableCentered;
    }

    // Método setter para habilitar/deshabilitar el centrado de la imagen
    public void setEnableCentered(boolean enableCentered) {
        this.enableCentered = enableCentered;
    }

    // Método que sobreescribe la pintura del componente
    @Override
    protected void paintComponent(Graphics grphcs) {
        // Se obtiene el contexto gráfico como Graphics2D
        Graphics2D g2d = (Graphics2D) grphcs;
        // Se configuran las propiedades de renderizado
        g2d.setRenderingHints(rh);

        // Se establece un borde vacío para evitar espacios alrededor del JLabel
        setBorder(new EmptyBorder(0, 0, 0, 0));

        // Se verifica si hay una imagen definida
        if (image != null) {
            // Si el ajuste de la altura está habilitado
            if (enableHeight) {
                // Se calcula la nueva altura manteniendo la proporción de la imagen
                double newHeight = ((double) image.getIconHeight() * (double) getWidth()) / (double) image.getIconWidth();
                int y = 0;
                // Si el centrado está habilitado, se calcula la posición Y centrada
                if (enableCentered) {
                    y = (int) ((getHeight() - newHeight) / 2);
                }
                // Se dibuja la imagen con la nueva altura
                g2d.drawImage(((ImageIcon) image).getImage(), 0, y, getWidth(), (int) newHeight, null);
            } else {
                // Si el ajuste de la altura está deshabilitado
                // Se calcula la nueva anchura manteniendo la proporción de la imagen
                double newWidth = ((double) image.getIconWidth() * (double) getHeight()) / (double) image.getIconHeight();
                int x = 0;
                // Si el centrado está habilitado, se calcula la posición X centrada
                if (enableCentered) {
                    x = (int) ((getWidth() - newWidth) / 2);
                }
                // Se dibuja la imagen con la nueva anchura
                g2d.drawImage(((ImageIcon) image).getImage(), x, 0, (int) newWidth, getHeight(), null);
            }
        }
        // Se llama al método paintComponent de la clase padre
        super.paintComponent(grphcs);
    }
}
