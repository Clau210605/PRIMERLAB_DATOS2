package Models;

/**
 * Una clase que contiene información sobre el árbol AVL.
 */
public class AVLTreeInfo {

    private final int maxLevel; // Nivel máximo del árbol.
    private final int maxWidth; // Ancho máximo del árbol.
    private final int maxWidthLevel; // Nivel donde se alcanza el ancho máximo del árbol.
    private final int nodesCount; // Cantidad de nodos en el árbol.
    private final int balanceFactor; // Factor de balance del árbol.
    private final boolean isBalanced; // Indica si el árbol está balanceado.
    private final int rotationCount; // Cantidad de rotaciones realizadas en el árbol.

    /**
     * Constructor de la clase AVLTreeInfo.
     * @param maxLevel Nivel máximo del árbol.
     * @param maxWidth Ancho máximo del árbol.
     * @param maxWidthLevel Nivel donde se alcanza el ancho máximo del árbol.
     * @param nodesCount Cantidad de nodos en el árbol.
     * @param balanceFactor Factor de balance del árbol.
     * @param isBalanced Indica si el árbol está balanceado.
     * @param rotationCount Cantidad de rotaciones realizadas en el árbol.
     */
    public AVLTreeInfo(int maxLevel, int maxWidth, int maxWidthLevel, int nodesCount,
                       int balanceFactor, boolean isBalanced, int rotationCount) {
        this.maxLevel = maxLevel;
        this.maxWidth = maxWidth;
        this.maxWidthLevel = maxWidthLevel;
        this.nodesCount = nodesCount;
        this.balanceFactor = balanceFactor;
        this.isBalanced = isBalanced;
        this.rotationCount = rotationCount;
    }

    // Métodos para obtener la información del árbol.

    public int getMaxLevel() {
        return maxLevel;
    }

    public int getMaxWidth() {
        return maxWidth;
    }

    public int getMaxWidthLevel() {
        return maxWidthLevel;
    }

    public int getNodesCount() {
        return nodesCount;
    }

    public int getBalanceFactor() {
        return balanceFactor;
    }

    public boolean isBalanced() {
        return isBalanced;
    }

    public int getRotationCount() {
        return rotationCount;
    }
}
