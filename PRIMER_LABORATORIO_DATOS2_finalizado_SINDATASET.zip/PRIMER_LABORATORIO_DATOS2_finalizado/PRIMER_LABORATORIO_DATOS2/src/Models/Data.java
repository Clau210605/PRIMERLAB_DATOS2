package Models;

import java.io.File;

/**
 * Data class to store the data of the dataset
 */
/**
 * Clase que representa los datos almacenados.
 */
public class Data {

    private String nombre; // Nombre del archivo.
    private long peso; // Peso del archivo en bytes.
    private String categoria; // Categoría del archivo.
    private File archivo; // Objeto File que representa el archivo.
    private File carpeta; // Objeto File que representa la carpeta.

    /**
     * Constructor por defecto de la clase Data.
     */
    public Data() {
    }

    /**
     * Constructor de la clase Data que inicializa los atributos.
     * @param nombre El nombre del archivo.
     * @param peso El peso del archivo en bytes.
     * @param categoria La categoría del archivo.
     * @param archivo El objeto File que representa el archivo.
     */
    public Data(String nombre, long peso, String categoria, File archivo) {
        this.nombre = nombre;
        this.peso = peso;
        this.categoria = categoria;
        this.archivo = archivo;
    }

    // Métodos para obtener y establecer los valores de los atributos.

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getPeso() {
        return peso;
    }

    public void setPeso(long peso) {
        this.peso = peso;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public File getCarpeta() {
        return carpeta;
    }

    public void setCarpeta(File carpeta) {
        this.carpeta = carpeta;
    }
}

