package Models; // Paquete donde se encuentra la clase

public class AVLNode<T> { // Definición de la clase AVLNode parametrizada por un tipo T

    T data; // Datos almacenados en el nodo
    int level = 1; // Nivel del nodo en el árbol
    AVLNode<T> left = null; // Referencia al hijo izquierdo del nodo
    AVLNode<T> right = null; // Referencia al hijo derecho del nodo

    public AVLNode(T data) { // Constructor que recibe los datos a almacenar en el nodo
        this.data = data;
    }

    public AVLNode<T> getLeft() { // Método para obtener el hijo izquierdo del nodo
        return left;
    }

    public void setLeft(AVLNode<T> left) { // Método para establecer el hijo izquierdo del nodo
        this.left = left;
    }

    public AVLNode<T> getRight() { // Método para obtener el hijo derecho del nodo
        return right;
    }

    public void setRight(AVLNode<T> right) { // Método para establecer el hijo derecho del nodo
        this.right = right;
    }

    public T getData() { // Método para obtener los datos almacenados en el nodo
        return data;
    }

    public void setData(T data) { // Método para establecer los datos del nodo
        this.data = data;
    }

    public int getLevel() { // Método para obtener el nivel del nodo en el árbol
        return level;
    }

    public void setLevel(int level) { // Método para establecer el nivel del nodo en el árbol
        this.level = level;
    }

    @Override
    public String toString() { // Método para representar el nodo como una cadena de texto
        return String.valueOf(data);
    }

}
