package Models; // Declaración del paquete donde se encuentra la clase AVLTree.

import Events.AVLTreeEvents; // Importación de la clase AVLTreeEvents desde el paquete Events.

import java.util.ArrayList; // Importación de la clase ArrayList desde el paquete java.util.
import java.util.Comparator; // Importación de la clase Comparator desde el paquete java.util.
import java.util.List; // Importación de la clase List desde el paquete java.util.
import java.util.function.Predicate; // Importación de la interfaz Predicate desde el paquete java.util.function.

public class AVLTree<T> { // Declaración de la clase AVLTree parametrizada por un tipo T.

    private AVLNode<T> root = null; // Declaración del nodo raíz del árbol AVL.

    private Comparator<T> comparer = Comparator.comparing(String::valueOf); // Declaración del comparador utilizado para comparar los datos de los nodos del árbol.

    private List<RotationInfo> rotationList = new ArrayList<>(); // Declaración de una lista que almacenará información sobre las rotaciones realizadas en el árbol.

    private int rotationCount = 0; // Declaración de una variable que almacenará el número de rotaciones realizadas en el árbol.

    private AVLTreeEvents events; // Declaración de eventos que se activarán cuando el árbol sea modificado.

    public Comparator<T> getComparer() { // Método para obtener el comparador del árbol AVL.
        return comparer;
    }

    public void setComparer(Comparator<T> comparer) { // Método para establecer el comparador del árbol AVL.
        this.comparer = comparer;
    }

    public AVLTreeEvents getEvents() { // Método para obtener los eventos del árbol AVL.
        return events;
    }

    public void setEvents(AVLTreeEvents events) { // Método para establecer los eventos del árbol AVL.
        this.events = events;
    }

    private class RotationInfo { // Declaración de una clase interna que representa la información de rotación.

        String rotation; // Dirección de la rotación.
        AVLNode<T> node; // Nodo afectado por la rotación.

        RotationInfo(String rotation, AVLNode<T> node) { // Constructor de la clase RotationInfo.
            this.rotation = rotation;
            this.node = node;
        }

        @Override
        public String toString() { // Método para representar la información de rotación como una cadena de texto.
            return "RotationInfo{"
                    + "rotation='" + rotation + '\''
                    + ", node=" + node
                    + '}';
        }
    }

    private int height(AVLNode<T> node) { // Método para obtener la altura de un nodo en el árbol.
        return node == null ? 0 : node.level; // Retorna 0 si el nodo es nulo, de lo contrario, retorna el nivel del nodo.
    }

    public int balanceFactor(AVLNode<T> node) { // Método para obtener el factor de balance de un nodo en el árbol.
        return node == null ? 0 : height(node.left) - height(node.right); // Retorna 0 si el nodo es nulo, de lo contrario, calcula la diferencia de alturas entre el hijo izquierdo y el hijo derecho del nodo.
    }

    private AVLNode<T> rotateRight(AVLNode<T> node) { // Método para realizar una rotación a la derecha en un nodo del árbol.
        AVLNode<T> newRoot = node.left; // Almacena el hijo izquierdo del nodo como el nuevo nodo raíz.
        node.left = newRoot.right; // El hijo derecho del nodo pasa a ser el hijo izquierdo del nuevo nodo raíz.
        newRoot.right = node; // El nodo original se convierte en el hijo derecho del nuevo nodo raíz.
        node.level = Math.max(height(node.left), height(node.right)) + 1; // Actualiza la altura del nodo original.
        newRoot.level = Math.max(height(newRoot.left), height(newRoot.right)) + 1; // Actualiza la altura del nuevo nodo raíz.
        rotationList.add(new RotationInfo("Right", node)); // Agrega información sobre la rotación a la lista de rotaciones.
        rotationCount++; // Incrementa el contador de rotaciones.
        return newRoot; // Retorna el nuevo nodo raíz.
    }

    private AVLNode<T> rotateLeft(AVLNode<T> node) { // Método para realizar una rotación a la izquierda en un nodo del árbol.
        AVLNode<T> newRoot = node.right; // Almacena el hijo derecho del nodo como el nuevo nodo raíz.
        node.right = newRoot.left; // El hijo izquierdo del nodo pasa a ser el hijo derecho del nuevo nodo raíz.
        newRoot.left = node; // El nodo original se convierte en el hijo izquierdo del nuevo nodo raíz.
        node.level = Math.max(height(node.left), height(node.right)) + 1; // Actualiza la altura del nodo original.
        newRoot.level = Math.max(height(newRoot.left), height(newRoot.right)) + 1; // Actualiza la altura del nuevo nodo raíz.
        rotationList.add(new RotationInfo("Left", node)); // Agrega información sobre la rotación a la lista de rotaciones.
        rotationCount++; // Incrementa el contador de rotaciones.
        return newRoot; // Retorna el nuevo nodo raíz.
    }

    private AVLNode<T> balance(AVLNode<T> node) { // Método para balancear un nodo del árbol AVL.
        int balanceFactor = height(node.right) - height(node.left); // Calcula el factor de balance del nodo.

        if (balanceFactor > 1) { // Si el factor de balance es mayor que 1, significa que está desbalanceado hacia la derecha.
            if (height(node.right.right) < height(node.right.left)) { // Si la altura del subárbol derecho derecho es menor que la altura del subárbol derecho izquierdo, se realiza una rotación a la derecha en el subárbol derecho.
                node.right = rotateRight(node.right); // Rotación a la derecha en el subárbol derecho.
            }
            return rotateLeft(node); // Rotación a la izquierda en el nodo actual.
        } else if (balanceFactor < -1) { // Si el factor de balance es menor que -1, significa que está desbalanceado hacia la izquierda.
            if (height(node.left.left) < height(node.left.right)) { // Si la altura del subárbol izquierdo izquierdo es menor que la altura del subárbol izquierdo derecho, se realiza una rotación a la izquierda en el subárbol izquierdo.
                node.left = rotateLeft(node.left); // Rotación a la izquierda en el subárbol izquierdo.
            }
            return rotateRight(node); // Rotación a la derecha en el nodo actual.
        }
        return node; // Retorna el nodo equilibrado.
    }

    public void insert(T value) { // Método para insertar un valor en el árbol AVL.
        root = insertInternal(root, value); // Llama al método interno de inserción comenzando desde la raíz.
    }

    private AVLNode<T> insertInternal(AVLNode<T> node, T value) { // Método interno para insertar un valor en el árbol AVL.
        if (node == null) { // Si el nodo actual es nulo, crea un nuevo nodo con el valor dado.
            return new AVLNode<T>(value);
        }

        if (comparer.compare(value, node.data) < 0) { // Compara el valor con el nodo actual y decide si se inserta en el subárbol izquierdo o derecho.
            node.left = insertInternal(node.left, value); // Llama recursivamente al método insertInternal para insertar en el subárbol izquierdo.
        } else {
            node.right = insertInternal(node.right, value); // Llama recursivamente al método insertInternal para insertar en el subárbol derecho.
        }

        node.level = Math.max(height(node.left), height(node.right)) + 1; // Actualiza la altura del nodo.

        return balance(node); // Equilibra el árbol después de la inserción y retorna el nodo raíz del subárbol.
    }

    public void printTree() { // Método para imprimir el árbol AVL.
        printTree(root, 0, "Root: "); // Llama al método de impresión comenzando desde la raíz.
    }

    private void printTree(AVLNode<T> root, int level, String prefix) { // Método para imprimir el árbol AVL.
        if (root == null) { // Si el nodo raíz es nulo, imprime que no hay elementos en ese nivel.
            System.out.println(" ".repeat(level) + prefix + "None");
            return;
        }
        System.out.println(" ".repeat(level) + prefix + "{"
                + "node=" + root // Imprime información sobre el nodo actual.
                + ", balance=" + balanceFactor(root) // Imprime el factor de balance del nodo actual.
                + '}');
        if (root.left != null) { // Si hay un hijo izquierdo, llama recursivamente al método de impresión para el subárbol izquierdo.
            printTree(root.left, level + 1, "L--- ");
        }
        if (root.right != null) { // Si hay un hijo derecho, llama recursivamente al método de impresión para el subárbol derecho.
            printTree(root.right, level + 1, "R--- ");
        }
    }

    public void refreshTree() { // Método para actualizar el árbol.
        // Paso 1: Guarda todos los datos actuales del árbol en una lista
        List<T> allData = new ArrayList<>(); // Crea una lista para almacenar todos los datos del árbol.
        retrieveData(root, allData); // Invoca el método retrieveData para recuperar todos los datos del árbol y almacenarlos en la lista.

        // Paso 2: Limpia el árbol
        this.root = null; // Establece el nodo raíz del árbol como nulo.
        this.rotationList.clear(); // Limpia la lista de rotaciones.
        this.rotationCount = 0; // Restablece el contador de rotaciones a cero.

        // Paso 3: Reinserta todos los datos en el árbol, usando el nuevo comparador
        for (T data : allData) { // Itera sobre todos los datos almacenados en la lista.
            insert(data); // Inserta cada dato en el árbol utilizando el método insert.
        }
    }

    private void retrieveData(AVLNode<T> node, List<T> allData) { // Método para recuperar todos los datos del árbol.
        if (node == null) { // Verifica si el nodo es nulo.
            return; // Si es nulo, termina la recursión.
        }

        allData.add(node.data); // Agrega el dato del nodo a la lista de datos.
        retrieveData(node.left, allData); // Recorre el subárbol izquierdo.
        retrieveData(node.right, allData); // Recorre el subárbol derecho.
    }

    public int getMaxLevel() { // Método para obtener el nivel máximo del árbol.
        return getMaxLevel(root); // Llama al método getMaxLevel pasando el nodo raíz como argumento.
    }

    private int getMaxLevel(AVLNode<T> node) { // Método recursivo para obtener el nivel máximo del árbol.
        if (node == null) { // Verifica si el nodo es nulo.
            return 0; // Si es nulo, retorna 0.
        }
        return 1 + Math.max(getMaxLevel(node.left), getMaxLevel(node.right)); // Retorna el máximo entre los niveles de los subárboles izquierdo y derecho, más 1.
    }

    public ArrayList<AVLNode<T>> getFullLevel(int level) { // Método para obtener todos los nodos de un nivel específico del árbol.
        ArrayList<AVLNode<T>> levelNodes = new ArrayList<>(); // Crea una lista para almacenar los nodos del nivel especificado.
        getFullLevel(root, level, 0, levelNodes); // Llama al método getFullLevel para obtener los nodos del nivel especificado.
        return levelNodes; // Retorna la lista de nodos del nivel especificado.
    }

    private void getFullLevel(AVLNode<T> node, int level, int currentLevel, ArrayList<AVLNode<T>> levelNodes) { // Método recursivo para obtener todos los nodos de un nivel específico del árbol.
        if (node == null) { // Verifica si el nodo es nulo.
            return; // Si es nulo, termina la recursión.
        }
        if (currentLevel == level) { // Verifica si el nivel actual es igual al nivel deseado.
            levelNodes.add(node); // Agrega el nodo al nivel deseado.
        } else {
            getFullLevel(node.left, level, currentLevel + 1, levelNodes); // Recorre el subárbol izquierdo.
            getFullLevel(node.right, level, currentLevel + 1, levelNodes); // Recorre el subárbol derecho.
        }
    }

    public void delete(Predicate<T> condition) { // Método para eliminar nodos que cumplan con cierta condición.
        List<AVLNode<T>> nodesToDelete = new ArrayList<>(); // Lista para almacenar los nodos que cumplen con la condición.
        findNodes(root, nodesToDelete, condition); // Encuentra los nodos que cumplen con la condición y los agrega a la lista.
        for (AVLNode<T> node : nodesToDelete) { // Itera sobre la lista de nodos a eliminar.
            delete(node); // Elimina cada nodo de la lista.
        }
    }

    public ArrayList<AVLNode<T>> search(Predicate<T> condition) { // Método para buscar nodos que cumplan con cierta condición.
        ArrayList<AVLNode<T>> nodes = new ArrayList<>(); // Lista para almacenar los nodos que cumplen con la condición.
        findNodes(root, nodes, condition); // Encuentra los nodos que cumplen con la condición y los agrega a la lista.
        return nodes; // Devuelve la lista de nodos encontrados.
    }

    private void findNodes(AVLNode<T> node, List<AVLNode<T>> nodes, Predicate<T> condition) { // Método para encontrar nodos que cumplan con cierta condición.
        if (node == null) { // Verifica si el nodo es nulo.
            return; // Si es nulo, termina la recursión.
        }
        if (condition.test(node.data)) { // Verifica si el nodo cumple con la condición.
            nodes.add(node); // Agrega el nodo a la lista.
        }
        findNodes(node.left, nodes, condition); // Recorre el subárbol izquierdo.
        findNodes(node.right, nodes, condition); // Recorre el subárbol derecho.
    }

    public void delete(AVLNode<T> targetNode) { // Método para eliminar un nodo específico del árbol.
        root = delete(root, targetNode); // Llama al método delete para eliminar el nodo específico y actualiza la raíz del árbol.
    }

    private AVLNode<T> delete(AVLNode<T> root, AVLNode<T> targetNode) { // Método para eliminar un nodo específico del árbol.
        if (root == null) { // Verifica si el nodo raíz es nulo.
            return root; // Si es nulo, devuelve el nodo raíz.
        }

        if (comparer.compare(targetNode.getData(), root.getData()) < 0) { // Compara los datos del nodo objetivo con el nodo raíz.
            root.setLeft(delete(root.getLeft(), targetNode)); // Elimina el nodo objetivo en el subárbol izquierdo.
        } else if (comparer.compare(targetNode.getData(), root.getData()) > 0) { // Compara los datos del nodo objetivo con el nodo raíz.
            root.setRight(delete(root.getRight(), targetNode)); // Elimina el nodo objetivo en el subárbol derecho.
        } else { // Si se encuentra el nodo objetivo.
            if ((root.getLeft() == null) || (root.getRight() == null)) { // Verifica si el nodo tiene uno o ningún hijo.
                AVLNode<T> temp = null;
                if (temp == root.getLeft()) { // Si el hijo izquierdo es nulo.
                    temp = root.getRight(); // Selecciona el hijo derecho como el nodo temporal.
                } else {
                    temp = root.getLeft(); // De lo contrario, selecciona el hijo izquierdo como el nodo temporal.
                }

                if (temp == null) { // Verifica si el nodo temporal es nulo.
                    root = null; // Si es nulo, elimina el nodo raíz.
                } else {
                    root = temp; // De lo contrario, actualiza el nodo raíz con el nodo temporal.
                }
            } else { // Si el nodo tiene ambos hijos.
                AVLNode<T> temp = findMin(root.getRight()); // Encuentra el nodo mínimo en el subárbol derecho.
                root.setData(temp.getData()); // Reemplaza los datos del nodo raíz con los datos del nodo mínimo.
                root.setRight(delete(root.getRight(), temp)); // Elimina el nodo mínimo en el subárbol derecho.
            }
        }

        if (root == null) { // Verifica si el nodo raíz es nulo.
            return root; // Si es nulo, devuelve el nodo raíz.
        }

        root.setLevel(Math.max(height(root.getLeft()), height(root.getRight())) + 1); // Actualiza el nivel del nodo raíz.
        int balance = balanceFactor(root); // Calcula el factor de equilibrio del nodo raíz.
// Aquí se verifican las condiciones para realizar rotaciones y se aplican si es necesario para mantener el balance del árbol AVL.
        if (balance > 1 && balanceFactor(root.getLeft()) >= 0) { // Verifica si el factor de equilibrio indica que se necesita una rotación a la derecha.
            return rotateRight(root); // Realiza una rotación a la derecha en el nodo raíz y devuelve el nuevo nodo raíz.
        }

        if (balance > 1 && balanceFactor(root.getLeft()) < 0) { // Verifica si se necesita una rotación doble (izquierda-derecha).
            root.setLeft(rotateLeft(root.getLeft())); // Realiza una rotación a la izquierda en el hijo izquierdo del nodo raíz.
            return rotateRight(root); // Realiza una rotación a la derecha en el nodo raíz y devuelve el nuevo nodo raíz.
        }

        if (balance < -1 && balanceFactor(root.getRight()) <= 0) { // Verifica si el factor de equilibrio indica que se necesita una rotación a la izquierda.
            return rotateLeft(root); // Realiza una rotación a la izquierda en el nodo raíz y devuelve el nuevo nodo raíz.
        }

        if (balance < -1 && balanceFactor(root.getRight()) > 0) { // Verifica si se necesita una rotación doble (derecha-izquierda).
            root.setRight(rotateRight(root.getRight())); // Realiza una rotación a la derecha en el hijo derecho del nodo raíz.
            return rotateLeft(root); // Realiza una rotación a la izquierda en el nodo raíz y devuelve el nuevo nodo raíz.
        }

        return root; // Si no se necesitan rotaciones, devuelve el nodo raíz sin cambios.

    }

    private AVLNode<T> findMin(AVLNode<T> node) {
        while (node.getLeft() != null) {
            node = node.getLeft();
        }
        return node;
    }

    public AVLTreeInfo getTreeInfo() {
        int maxLevel = getMaxLevel();
        int nodesCount = getNodesCount(root);
        LevelWidthInfo levelWidthInfo = getMaxWidth();
        int balanceFactor = balanceFactor(root);
        boolean isBalanced = isTreeBalanced(root);

        return new AVLTreeInfo(maxLevel, levelWidthInfo.maxWidth,
                levelWidthInfo.level, nodesCount, balanceFactor,
                isBalanced, rotationCount);
    }

    /**
     * Method to get the number of nodes of the tree.
     *
     * @param node The root of the subtree.
     * @return The number of nodes of the tree.
     */
    private int getNodesCount(AVLNode<T> node) {
        if (node == null) {
            return 0;
        }
        return 1 + getNodesCount(node.left) + getNodesCount(node.right);
    }

    /**
     * Method to check if the tree is balanced.
     *
     * @param node The root of the subtree.
     * @return True if the tree is balanced, false otherwise.
     */
    private boolean isTreeBalanced(AVLNode<T> node) {
        if (node == null) {
            return true;
        }
        int balance = balanceFactor(node);
        return (balance >= -1 && balance <= 1) && isTreeBalanced(node.left) && isTreeBalanced(node.right);
    }

    /**
     * Method to get the maximum width of the tree.
     *
     * @return The maximum width of the tree.
     */
    private LevelWidthInfo getMaxWidth() {
        int maxLevels = getMaxLevel();
        int maxWidth = 0;
        int maxWidthLevel = 0;
        for (int i = 0; i < maxLevels; i++) {
            int currentWidth = getFullLevel(i).size();
            if (currentWidth > maxWidth) {
                maxWidth = currentWidth;
                maxWidthLevel = i;
            }
        }
        return new LevelWidthInfo(maxWidth, maxWidthLevel);
    }

    /**
     * A class that represents the information of the tree.
     */
    private class LevelWidthInfo {

        int maxWidth;
        int level;

        LevelWidthInfo(int maxWidth, int level) {
            this.maxWidth = maxWidth;
            this.level = level;
        }
    }

    /**
     * Method to get the root of the tree.
     *
     * @return The root of the tree.
     */
    public AVLNode<T> getRoot() {
        return root;
    }

    /**
     * Method to get the list of rotations that were made.
     *
     * @return The list of rotations that were made.
     */
    public NodeFamily<T> findNodeFamily(AVLNode<T> node) {
        return findNodeFamily(null, null, root, node);
    }

    /**
     * Método para encontrar la familia de nodos de un nodo específico en el
     * árbol.
     *
     * @param grandParent El abuelo del nodo.
     * @param parent El padre del nodo.
     * @param node El nodo actual.
     * @param data El nodo cuya familia se está buscando.
     * @return Un objeto NodeFamily que contiene información sobre la familia
     * del nodo.
     */
    private NodeFamily<T> findNodeFamily(AVLNode<T> grandParent, AVLNode<T> parent, AVLNode<T> node, AVLNode<T> data) {
        if (node == null) {
            return null;
        }

        if (node == data) { // Si el nodo actual es el nodo buscado.
            NodeFamily<T> family = new NodeFamily<>(); // Crea un nuevo objeto NodeFamily.
            family.parent = parent; // Establece el padre del nodo.
            family.grandParent = grandParent; // Establece el abuelo del nodo.

            // Calcula al tío del nodo.
            if (grandParent != null) {
                family.uncle = (grandParent.getLeft() == parent) ? grandParent.getRight() : grandParent.getLeft();
            }

            return family; // Devuelve la familia del nodo.
        }

        // Busca recursivamente en el subárbol izquierdo.
        NodeFamily<T> family = findNodeFamily(parent, node, node.getLeft(), data);
        if (family != null) {
            return family;
        }

        // Busca recursivamente en el subárbol derecho.
        return findNodeFamily(parent, node, node.getRight(), data);
    }

    /**
     * Método para activar los eventos del árbol.
     */
    public void refreshEveryWhere() {
        System.out.println("Cantidad de nodos: " + getTreeInfo().getNodesCount()); // Imprime la cantidad de nodos en el árbol.
        events.treeModified(); // Activa los eventos indicando que el árbol ha sido modificado.
    }

    /**
     * Método para obtener todos los nodos del árbol.
     *
     * @return Una lista que contiene todos los nodos del árbol.
     */
    public ArrayList<AVLNode<T>> getAllNodes() {
        ArrayList<AVLNode<T>> nodes = new ArrayList<>(); // Crea una lista para almacenar los nodos.
        getAllNodes(root, nodes); // Llama al método recursivo para recorrer el árbol y recolectar los nodos.
        return nodes; // Devuelve la lista de nodos.
    }

    /**
     * Método recursivo para obtener todos los nodos del árbol.
     *
     * @param node El nodo actual en el recorrido.
     * @param nodes La lista donde se almacenarán los nodos.
     */
    private void getAllNodes(AVLNode<T> node, ArrayList<AVLNode<T>> nodes) {
        if (node == null) {
            return;
        }
        nodes.add(node); // Agrega el nodo actual a la lista.
        getAllNodes(node.left, nodes); // Recorre el subárbol izquierdo.
        getAllNodes(node.right, nodes); // Recorre el subárbol derecho.
    }

}
