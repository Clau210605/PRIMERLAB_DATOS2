package Models;

/**
 * Clase que representa una familia de nodos en un árbol AVL.
 *
 * @param <T> El tipo de datos almacenado en los nodos.
 */
public class NodeFamily<T> {

    /**
     * El nodo padre.
     */
    public AVLNode<T> parent;

    /**
     * El abuelo del nodo.
     */
    public AVLNode<T> grandParent;

    /**
     * El tío del nodo.
     */
    public AVLNode<T> uncle;

    /**
     * Devuelve una representación en forma de cadena de la familia de nodos.
     *
     * @return Representación en forma de cadena de la familia de nodos.
     */
    @Override
    public String toString() {
        return "NodeFamily{"
                + "parent=" + (parent != null ? parent.getData() : "null")
                + ", grandParent=" + (grandParent != null ? grandParent.getData() : "null")
                + ", uncle=" + (uncle != null ? uncle.getData() : "null")
                + '}';
    }
}
