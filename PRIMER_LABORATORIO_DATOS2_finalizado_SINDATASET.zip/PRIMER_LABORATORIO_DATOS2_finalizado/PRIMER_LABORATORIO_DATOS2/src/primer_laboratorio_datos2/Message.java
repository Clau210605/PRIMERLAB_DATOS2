package primer_laboratorio_datos2;

import java.awt.Color;
import javax.swing.Timer;

public class Message extends javax.swing.JFrame {

    public Message(String text, int time) {
        initComponents();
        setBackground(new Color(0, 0, 0, 0));
        label.setText(text);
        timer = new Timer(time, e -> setVisible(false));
        setVisible(true);
        timer.start();
    }

    Timer timer;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        background = new Custom.PanelRound();
        label = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        background.setBackground(new java.awt.Color(243, 243, 243));
        background.setRadius(50);
        background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label.setFont(new java.awt.Font("Rubik", 0, 24)); // NOI18N
        label.setForeground(new java.awt.Color(102, 102, 102));
        label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label.setText("Message");
        background.add(label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 380, 70));

        getContentPane().add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 160));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Custom.PanelRound background;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel label;
    // End of variables declaration//GEN-END:variables

}
