package primer_laboratorio_datos2; // Paquete donde se encuentra la clase

import Events.AVLTreeEvents; // Importación de clases de eventos AVLTreeEvents
import Events.ImageViewerEvent; // Importación de clases de eventos ImageViewerEvent
import Events.TreeDrawerEvent; // Importación de clases de eventos TreeDrawerEvent
import Models.AVLNode; // Importación de clases del modelo AVLNode
import Models.AVLTree; // Importación de clases del modelo AVLTree
import Models.Data; // Importación de clases del modelo Data
import Models.NodeFamily; // Importación de clases del modelo NodeFamily
import javax.swing.*; // Importación de clases Swing
import java.awt.Color; // Importación de clases para manejar colores
import java.io.File; // Importación de clases para manejar archivos
import java.util.ArrayList; // Importación de clases para manejar ArrayList
import java.util.Comparator; // Importación de clases para manejar comparadores
import java.util.Random; // Importación de clases para manejar números aleatorios

public class OPCIONES extends javax.swing.JFrame { // Definición de la clase OPCIONES que extiende JFrame

    int xmouse, ymouse; // Declaración de variables para manejar posición del mouse.
    AVLTree<Data> arbol; // Declaración de un árbol AVL de tipo Data

    public OPCIONES() { // Constructor de la clase OPCIONES
        initComponents(); // Inicialización de componentes de la interfaz gráfica
        setLocationRelativeTo(null); // Establecer la ubicación de la ventana en el centro de la pantalla
        setBackground(new Color(0, 0, 0, 0)); // Establecer el fondo de la ventana como transparente

        arbol = new AVLTree<>(); // Inicialización del árbol AVL
        arbol.setComparer(Comparator.comparing(Data::getNombre)); // Establecer un comparador para ordenar el árbol por el nombre de los datos

        File carpetaDeDatos = new File("src/../resources/data"); // Crear un objeto de tipo File que representa la carpeta de datos
        Random rn = new Random(); // Inicialización de un objeto Random para generar números aleatorios

        for (File carpeta : carpetaDeDatos.listFiles()) { // Iterar sobre las carpetas dentro de la carpeta de datos
            File[] archivos = carpeta.listFiles(); // Obtener la lista de archivos dentro de la carpeta

            for (int i = 0; i < 3; i++) { // Realizar un bucle para seleccionar aleatoriamente 3 archivos de cada carpeta
                File archivo = archivos[rn.nextInt(archivos.length)]; // Seleccionar aleatoriamente un archivo de la lista
                Data data = new Data(); // Crear un nuevo objeto Data
                data.setNombre(archivo.getName()); // Establecer el nombre del archivo en el objeto Data
                data.setCategoria(carpeta.getName()); // Establecer el nombre de la categoría en el objeto Data
                data.setPeso(archivo.length()); // Establecer el tamaño del archivo en el objeto Data
                data.setArchivo(archivo); // Establecer el archivo en el objeto Data
                data.setCarpeta(carpeta); // Establecer la carpeta del archivo en el objeto Data

                arbol.insert(data); // Insertar el objeto Data en el árbol AVL
            }
        }

        treeDrawer1.setShow(Data::getNombre); // Establecer la función de visualización de los datos en el TreeDrawer1
        treeDrawer1.setTree(arbol); // Establecer el árbol en el TreeDrawer1
        treeDrawer1.setEvents(new TreeDrawerEvent<>() { // Establecer eventos para el TreeDrawer1
            @Override
            public void nodeSelected(AVLNode<Data> selectedNode, int nodeIndex) { // Método llamado cuando se selecciona un nodo en el TreeDrawer1
                Data data = selectedNode.getData(); // Obtener los datos del nodo seleccionado
                nameLabel.setText(data.getNombre()); // Establecer el nombre en el label correspondiente
                categoryLabel.setText(data.getCategoria()); // Establecer la categoría en el label correspondiente
                weigthLabel.setText(data.getPeso() + " bytes"); // Establecer el peso en el label correspondiente
                pathLabel.setText(data.getArchivo().getAbsolutePath()); // Establecer la ruta del archivo en el label correspondiente

                NodeFamily<Data> family = arbol.findNodeFamily(selectedNode); // Obtener la familia del nodo seleccionado en el árbol

                grandfatherLabel.setText(family.grandParent != null ? family.grandParent.getData().getNombre() : "No tiene abuelo"); // Establecer el nombre del abuelo en el label correspondiente
                fatherLabel.setText(family.parent != null ? family.parent.getData().getNombre() : "No tiene padre"); // Establecer el nombre del padre en el label correspondiente
                uncleLabel.setText(family.uncle != null ? family.uncle.getData().getNombre() : "No tiene tio"); // Establecer el nombre del tío en el label correspondiente

                levelLabel.setText("Nivel " + (arbol.getMaxLevel() - selectedNode.getLevel())); // Establecer el nivel del nodo en el label correspondiente
                balanceLabel.setText(arbol.balanceFactor(selectedNode) + " balance"); // Establecer el factor de balance en el label correspondiente

                imageLabel.setImage(new ImageIcon(data.getArchivo().getAbsolutePath())); // Establecer la imagen correspondiente en el label
            }

            @Override
            public void nodeUnselected() { // Método llamado cuando se deselecciona un nodo en el TreeDrawer1
                System.out.println("Nodo deseleccionado"); // Imprimir un mensaje en la consola
            }
        });

        for (File carpeta : carpetaDeDatos.listFiles()) { // Iterar sobre las carpetas dentro de la carpeta de datos
            for (File archivo : carpeta.listFiles()) { // Iterar sobre los archivos dentro de cada carpeta
                imageViewer1.addFile(archivo, carpeta); // Agregar el archivo al visor de imágenes
            }
        }
        imageViewer1.setEvents((file, folder) -> { // Establecer eventos para el visor de imágenes
            System.out.println("Event"); // Imprimir un mensaje en la consola

            Data data = new Data(); // Crear un nuevo objeto Data
            data.setNombre(file.getName()); // Establecer el nombre del archivo en el objeto Data
            data.setCategoria(folder.getName()); // Establecer la categoría del archivo en el objeto Data
            data.setPeso(file.length()); // Establecer el peso del archivo en el objeto Data
            data.setArchivo(file); // Establecer el archivo en el objeto Data

            arbol.insert(data); // Insertar el objeto Data en el árbol AVL
            treeDrawer1.setTree(arbol); // Establecer el árbol en el TreeDrawer1
            treeDrawer1.repaint(); // Volver a pintar el TreeDrawer1
            treeDrawer1.revalidate(); // Volver a validar el TreeDrawer1

            new Message(file.getName() + " añadido", 2000); // Mostrar un mensaje de confirmación de que el archivo fue añadido
        });

        BARRA.setBackground(new Color(0, 0, 0, 0)); // Establecer el color de fondo de la barra como transparente
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        blurBackground1 = new Custom.BlurBackground();
        BARRA = new javax.swing.JPanel();
        BtnEXIT = new javax.swing.JButton();
        BOTON_CERRAR = new javax.swing.JButton();
        panelRound2 = new Custom.PanelRound();
        imageButton1 = new Custom.ImageButton();
        imageButton2 = new Custom.ImageButton();
        imageButton3 = new Custom.ImageButton();
        tabs = new Custom.CustomTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        panelRound1 = new Custom.PanelRound();
        treeDrawer1 = new Custom.TreeDrawer<>();
        weigthLabel = new javax.swing.JLabel();
        categoryLabel = new javax.swing.JLabel();
        logoLabel7 = new Custom.LogoLabel();
        nameLabel = new javax.swing.JLabel();
        pathLabel = new javax.swing.JLabel();
        logoLabel8 = new Custom.LogoLabel();
        grandfatherLabel = new javax.swing.JLabel();
        logoLabel9 = new Custom.LogoLabel();
        fatherLabel = new javax.swing.JLabel();
        logoLabel10 = new Custom.LogoLabel();
        logoLabel11 = new Custom.LogoLabel();
        uncleLabel = new javax.swing.JLabel();
        panelRound7 = new Custom.PanelRound();
        imageLabel = new Custom.LogoLabel();
        balanceLabel = new javax.swing.JLabel();
        logoLabel12 = new Custom.LogoLabel();
        logoLabel13 = new Custom.LogoLabel();
        levelLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        panelRound3 = new Custom.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        imageViewer1 = new Custom.ImageViewer();
        jPanel3 = new javax.swing.JPanel();
        nodesCombobox = new javax.swing.JComboBox<>();
        eliminarButton = new javax.swing.JButton();
        archivoLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelRound4 = new Custom.PanelRound();
        imagenLabel = new javax.swing.JLabel();
        recargarButton = new javax.swing.JButton();
        carpetaLabel = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        panelRound5 = new Custom.PanelRound();
        jScrollPane2 = new javax.swing.JScrollPane();
        searchViewer = new Custom.ImageViewer();
        recargarButton1 = new javax.swing.JButton();
        pesoField = new javax.swing.JTextField();
        nombreField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        categoriaField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        imageButton4 = new Custom.ImageButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        blurBackground1.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/FONDO_ELEGIDO_OPCIONES.png"))); // NOI18N
        blurBackground1.setRadius(55);
        blurBackground1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BARRA.setBackground(new java.awt.Color(255, 255, 255));
        BARRA.setForeground(new java.awt.Color(255, 255, 255));
        BARRA.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                BARRAMouseDragged(evt);
            }
        });
        BARRA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BARRAMousePressed(evt);
            }
        });
        BARRA.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BtnEXIT.setBorder(null);
        BtnEXIT.setBorderPainted(false);
        BtnEXIT.setContentAreaFilled(false);
        BtnEXIT.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnEXIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEXITActionPerformed(evt);
            }
        });
        BARRA.add(BtnEXIT, new org.netbeans.lib.awtextra.AbsoluteConstraints(1031, 52, 44, -1));

        BOTON_CERRAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/CIRCULITO_DE_CERRAR.png"))); // NOI18N
        BOTON_CERRAR.setBorder(null);
        BOTON_CERRAR.setBorderPainted(false);
        BOTON_CERRAR.setContentAreaFilled(false);
        BOTON_CERRAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BOTON_CERRAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTON_CERRARActionPerformed(evt);
            }
        });
        BARRA.add(BOTON_CERRAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 10, 50, 50));

        panelRound2.setBackground(new java.awt.Color(255, 255, 255));
        panelRound2.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelRound2Layout = new javax.swing.GroupLayout(panelRound2);
        panelRound2.setLayout(panelRound2Layout);
        panelRound2Layout.setHorizontalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );
        panelRound2Layout.setVerticalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        BARRA.add(panelRound2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 10, 50, 50));

        blurBackground1.add(BARRA, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, -1));

        imageButton1.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_search_90px.png"))); // NOI18N
        imageButton1.setImageOver(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_search_90px_1.png"))); // NOI18N
        imageButton1.setImagePressed(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_search_90px_2.png"))); // NOI18N
        imageButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageButton1ActionPerformed(evt);
            }
        });
        blurBackground1.add(imageButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 630, 70, 70));

        imageButton2.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_genealogy_500px.png"))); // NOI18N
        imageButton2.setImageOver(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_genealogy_500px_1.png"))); // NOI18N
        imageButton2.setImagePressed(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_genealogy_500px_2.png"))); // NOI18N
        imageButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageButton2ActionPerformed(evt);
            }
        });
        blurBackground1.add(imageButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 630, 70, 70));

        imageButton3.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_add_90px.png"))); // NOI18N
        imageButton3.setImageOver(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_add_90px_1.png"))); // NOI18N
        imageButton3.setImagePressed(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_add_90px_2.png"))); // NOI18N
        imageButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageButton3ActionPerformed(evt);
            }
        });
        blurBackground1.add(imageButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 630, 70, 70));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound1.setBackground(new java.awt.Color(232, 117, 163));
        panelRound1.setEnableCustomRectangle(true);
        panelRound1.setRadius(50);
        panelRound1.setRoundBottomLeft(50);
        panelRound1.setRoundBottomRight(50);
        panelRound1.setRoundTopLeft(50);
        panelRound1.setRoundTopRight(50);
        panelRound1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        treeDrawer1.setBackground(new java.awt.Color(232, 117, 163));
        treeDrawer1.setForeground(new java.awt.Color(51, 51, 51));
        treeDrawer1.setFont(new java.awt.Font("Montserrat Light", 0, 18)); // NOI18N
        treeDrawer1.setNodeColor(new java.awt.Color(255, 255, 255));
        treeDrawer1.setNodeSize(150.0);

        javax.swing.GroupLayout treeDrawer1Layout = new javax.swing.GroupLayout(treeDrawer1);
        treeDrawer1.setLayout(treeDrawer1Layout);
        treeDrawer1Layout.setHorizontalGroup(
            treeDrawer1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 920, Short.MAX_VALUE)
        );
        treeDrawer1Layout.setVerticalGroup(
            treeDrawer1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 550, Short.MAX_VALUE)
        );

        panelRound1.add(treeDrawer1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 920, 550));

        jPanel1.add(panelRound1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 940, 570));

        weigthLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        weigthLabel.setForeground(new java.awt.Color(51, 51, 51));
        weigthLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        weigthLabel.setText("Peso del archivo");
        jPanel1.add(weigthLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 270, 180, 30));

        categoryLabel.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        categoryLabel.setForeground(new java.awt.Color(51, 51, 51));
        categoryLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        categoryLabel.setText("Categoria del nodo");
        jPanel1.add(categoryLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 80, 290, 20));

        logoLabel7.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_sd_50px.png"))); // NOI18N
        jPanel1.add(logoLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 270, 30, 30));

        nameLabel.setFont(new java.awt.Font("Montserrat Light", 0, 20)); // NOI18N
        nameLabel.setForeground(new java.awt.Color(51, 51, 51));
        nameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nameLabel.setText("Nombre del nodo");
        jPanel1.add(nameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 40, 290, 40));

        pathLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        pathLabel.setForeground(new java.awt.Color(51, 51, 51));
        pathLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        pathLabel.setText("Ruta del archivo");
        jPanel1.add(pathLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 305, 180, 30));

        logoLabel8.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_polyline_50px.png"))); // NOI18N
        jPanel1.add(logoLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 305, 30, 30));

        grandfatherLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        grandfatherLabel.setForeground(new java.awt.Color(51, 51, 51));
        grandfatherLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        grandfatherLabel.setText("Abuelo del nodo");
        jPanel1.add(grandfatherLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 395, 180, 30));

        logoLabel9.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_grandfather_50px_1.png"))); // NOI18N
        jPanel1.add(logoLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 395, 30, 30));

        fatherLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        fatherLabel.setForeground(new java.awt.Color(51, 51, 51));
        fatherLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        fatherLabel.setText("Padre del nodo");
        jPanel1.add(fatherLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 360, 180, 30));

        logoLabel10.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_family_50px.png"))); // NOI18N
        jPanel1.add(logoLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 360, 30, 30));

        logoLabel11.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_old_man_50px.png"))); // NOI18N
        jPanel1.add(logoLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 430, 30, 30));

        uncleLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        uncleLabel.setForeground(new java.awt.Color(51, 51, 51));
        uncleLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        uncleLabel.setText("Tio del nodo");
        jPanel1.add(uncleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 430, 180, 30));

        panelRound7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelRound7.add(imageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 230, 130));

        jPanel1.add(panelRound7, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 110, 250, 150));

        balanceLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        balanceLabel.setForeground(new java.awt.Color(51, 51, 51));
        balanceLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        balanceLabel.setText("Balanceo del nodo");
        jPanel1.add(balanceLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 525, 180, 30));

        logoLabel12.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_scales_50px.png"))); // NOI18N
        jPanel1.add(logoLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 525, 30, 30));

        logoLabel13.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_no_connection_50px.png"))); // NOI18N
        jPanel1.add(logoLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 490, 30, 30));

        levelLabel.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        levelLabel.setForeground(new java.awt.Color(51, 51, 51));
        levelLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        levelLabel.setText("Nivel del nodo");
        jPanel1.add(levelLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 490, 180, 30));

        tabs.addTab("tab2", jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound3.setBackground(new java.awt.Color(232, 117, 163));
        panelRound3.setEnableCustomRectangle(true);
        panelRound3.setRadius(50);
        panelRound3.setRoundBottomLeft(50);
        panelRound3.setRoundBottomRight(50);
        panelRound3.setRoundTopLeft(50);
        panelRound3.setRoundTopRight(50);
        panelRound3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(232, 117, 163));
        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        imageViewer1.setBackground(new java.awt.Color(232, 117, 163));
        jScrollPane1.setViewportView(imageViewer1);

        panelRound3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 1190, 530));

        jPanel2.add(panelRound3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1230, 570));

        tabs.addTab("tab2", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nodesCombobox.setFont(new java.awt.Font("Montserrat Light", 0, 24)); // NOI18N
        nodesCombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nodesComboboxActionPerformed(evt);
            }
        });
        jPanel3.add(nodesCombobox, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 380, 50));

        eliminarButton.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        eliminarButton.setText("Eliminar");
        eliminarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarButtonActionPerformed(evt);
            }
        });
        jPanel3.add(eliminarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 480, 180, 40));

        archivoLabel.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        archivoLabel.setForeground(new java.awt.Color(51, 51, 51));
        archivoLabel.setText("Archivo: ");
        jPanel3.add(archivoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 260, 340, 30));

        jLabel2.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("Nodos arbol AVL:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 340, 20));

        panelRound4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelRound4.add(imagenLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 220, 130));

        jPanel3.add(panelRound4, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 300, 240, 150));

        recargarButton.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        recargarButton.setText("Recargar");
        recargarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recargarButtonActionPerformed(evt);
            }
        });
        jPanel3.add(recargarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 70, 180, 40));

        carpetaLabel.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        carpetaLabel.setForeground(new java.awt.Color(51, 51, 51));
        carpetaLabel.setText("Carpeta: ");
        jPanel3.add(carpetaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 340, 30));

        tabs.addTab("tab3", jPanel3);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelRound5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setBackground(new java.awt.Color(60, 63, 65));
        jScrollPane2.setBorder(null);
        jScrollPane2.setViewportView(searchViewer);

        panelRound5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1170, 390));

        jPanel4.add(panelRound5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 1190, 410));

        recargarButton1.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        recargarButton1.setText("Buscar");
        recargarButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recargarButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(recargarButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 70, 180, 50));

        pesoField.setBackground(new java.awt.Color(255, 255, 255));
        pesoField.setFont(new java.awt.Font("Montserrat Light", 0, 18)); // NOI18N
        pesoField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel4.add(pesoField, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 70, 290, 50));

        nombreField.setBackground(new java.awt.Color(255, 255, 255));
        nombreField.setFont(new java.awt.Font("Montserrat Light", 0, 18)); // NOI18N
        nombreField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel4.add(nombreField, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 290, 50));

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Peso - Menor que");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 40, 160, 30));

        jLabel3.setBackground(new java.awt.Color(51, 51, 51));
        jLabel3.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("Nombre - Igual");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 160, 30));

        categoriaField.setBackground(new java.awt.Color(255, 255, 255));
        categoriaField.setFont(new java.awt.Font("Montserrat Light", 0, 18)); // NOI18N
        categoriaField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel4.add(categoriaField, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 70, 290, 50));

        jLabel4.setBackground(new java.awt.Color(51, 51, 51));
        jLabel4.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Categoria - Igual");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 40, 160, 30));

        tabs.addTab("tab4", jPanel4);

        blurBackground1.add(tabs, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1260, 590));

        imageButton4.setImage(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_cancel_90px.png"))); // NOI18N
        imageButton4.setImageOver(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_cancel_90px_2.png"))); // NOI18N
        imageButton4.setImagePressed(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/icons8_cancel_90px_3.png"))); // NOI18N
        imageButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageButton4ActionPerformed(evt);
            }
        });
        blurBackground1.add(imageButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 630, 70, 70));

        getContentPane().add(blurBackground1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnEXITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEXITActionPerformed

    }//GEN-LAST:event_BtnEXITActionPerformed

    private void BOTON_CERRARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTON_CERRARActionPerformed
        this.dispose();// Cierra la ventana actual desde la que se está llamando a este código.
    }//GEN-LAST:event_BOTON_CERRARActionPerformed

    private void BARRAMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BARRAMouseDragged
        int x = evt.getXOnScreen(); //Obttiene la posicion horizontal actual en pantalla.
        int y = evt.getYOnScreen(); //Obtiene la posicion vertical actual en pantalla.
        this.setLocation(x - xmouse, y - ymouse); //Establece la poscion de la ventana en funcion de la posicion original del mouse.
    }//GEN-LAST:event_BARRAMouseDragged

    private void BARRAMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BARRAMousePressed
        xmouse = evt.getX(); // Obtiene la posicion horizontal del punto donde se hizo clic.
        ymouse = evt.getY(); // Obtiene la posicion vertical del punto donde se hizo clic.
    }//GEN-LAST:event_BARRAMousePressed

    private void imageButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageButton1ActionPerformed
        tabs.setSelectedIndex(3);// Establece el índice de la pestaña seleccionada en el componente tabs.
    }//GEN-LAST:event_imageButton1ActionPerformed

    private void imageButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageButton2ActionPerformed
        tabs.setSelectedIndex(0);// Establece el índice de la pestaña seleccionada en el componente tabs.
    }//GEN-LAST:event_imageButton2ActionPerformed

    private void imageButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageButton3ActionPerformed
        tabs.setSelectedIndex(1);// Establece el índice de la pestaña seleccionada en el componente tabs.
    }//GEN-LAST:event_imageButton3ActionPerformed

    private void imageButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageButton4ActionPerformed
        tabs.setSelectedIndex(2);// Establece el índice de la pestaña seleccionada en el componente tabs.
    }//GEN-LAST:event_imageButton4ActionPerformed

    private void recargarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recargarButtonActionPerformed
        reload();// Llama al método "reload()" para realizar alguna acción de recargar los nodos del arbol que se crearon en esa ejecucion. 
    }//GEN-LAST:event_recargarButtonActionPerformed

    private void eliminarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarButtonActionPerformed
        String selected = nodesCombobox.getSelectedItem().toString(); // Obtiene el elemento seleccionado del JComboBox "nodesCombobox" como una cadena de texto.
        arbol.delete((data) -> data.getNombre().equals(selected)); // Elimina del árbol AVL el nodo cuyo nombre coincide con el elemento seleccionado.
        treeDrawer1.setTree(arbol); // Establece el árbol actualizado en el TreeDrawer1.
        treeDrawer1.repaint(); // Vuelve a pintar el TreeDrawer1 para reflejar los cambios realizados.
        reload(); // Llama al método "reload()" para realizar alguna acción de recarga en el contexto específico de la aplicación.


    }//GEN-LAST:event_eliminarButtonActionPerformed

    private void nodesComboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nodesComboboxActionPerformed
        setSelectedCombobox(); // Llama al método "setSelectedCombobox()" para realizar alguna acción relacionada con la selección en un JComboBox u otro componente similar, específico para el contexto de la aplicación.
    }//GEN-LAST:event_nodesComboboxActionPerformed

    private void recargarButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recargarButton1ActionPerformed
        search(); // Llama al método "search()" para realizar alguna acción relacionada con la búsqueda de elementos, específica para el contexto de la aplicación.
    }//GEN-LAST:event_recargarButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OPCIONES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OPCIONES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OPCIONES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OPCIONES.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OPCIONES().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BARRA;
    private javax.swing.JButton BOTON_CERRAR;
    private javax.swing.JButton BtnEXIT;
    private javax.swing.JLabel archivoLabel;
    private javax.swing.JLabel balanceLabel;
    private Custom.BlurBackground blurBackground1;
    private javax.swing.JLabel carpetaLabel;
    private javax.swing.JTextField categoriaField;
    private javax.swing.JLabel categoryLabel;
    private javax.swing.JButton eliminarButton;
    private javax.swing.JLabel fatherLabel;
    private javax.swing.JLabel grandfatherLabel;
    private Custom.ImageButton imageButton1;
    private Custom.ImageButton imageButton2;
    private Custom.ImageButton imageButton3;
    private Custom.ImageButton imageButton4;
    private Custom.LogoLabel imageLabel;
    private Custom.ImageViewer imageViewer1;
    private javax.swing.JLabel imagenLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel levelLabel;
    private Custom.LogoLabel logoLabel10;
    private Custom.LogoLabel logoLabel11;
    private Custom.LogoLabel logoLabel12;
    private Custom.LogoLabel logoLabel13;
    private Custom.LogoLabel logoLabel7;
    private Custom.LogoLabel logoLabel8;
    private Custom.LogoLabel logoLabel9;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JComboBox<String> nodesCombobox;
    private javax.swing.JTextField nombreField;
    private Custom.PanelRound panelRound1;
    private Custom.PanelRound panelRound2;
    private Custom.PanelRound panelRound3;
    private Custom.PanelRound panelRound4;
    private Custom.PanelRound panelRound5;
    private Custom.PanelRound panelRound7;
    private javax.swing.JLabel pathLabel;
    private javax.swing.JTextField pesoField;
    private javax.swing.JButton recargarButton;
    private javax.swing.JButton recargarButton1;
    private Custom.ImageViewer searchViewer;
    private Custom.CustomTabbedPane tabs;
    private Custom.TreeDrawer<Data> treeDrawer1;
    private javax.swing.JLabel uncleLabel;
    private javax.swing.JLabel weigthLabel;
    // End of variables declaration//GEN-END:variables

    private void reload() {
        ArrayList<AVLNode<Data>> nodes = arbol.getAllNodes();

        nodesCombobox.removeAllItems();
        nodes.forEach(node -> nodesCombobox.addItem(node.getData().getNombre()));
    }

    private void setSelectedCombobox() {
        if (nodesCombobox.getSelectedItem() != null) {
            String selected = nodesCombobox.getSelectedItem().toString();
            AVLNode<Data> node = arbol.search((data) -> data.getNombre().equals(selected)).get(0);

            if (node != null) {
                Data data = node.getData();
                archivoLabel.setText("Archivo: " + data.getNombre());
                carpetaLabel.setText("Carpeta: " + data.getCategoria());
                imagenLabel.setIcon(new ImageIcon(data.getArchivo().getAbsolutePath()));
            }
        }
    }

    public void search() {
        String nombre = nombreField.getText().strip();
        String peso = pesoField.getText().strip();
        String categoria = categoriaField.getText().strip();

        System.out.println("Entro");

        ArrayList<AVLNode<Data>> nodes = arbol.search((data) -> {
            boolean nombreMatch = !nombre.equals("") && data.getNombre().contains(nombre);
            boolean categoriaMatch = !categoria.equals("") && data.getCategoria().contains(categoria);
            boolean pesoMatch;
            try {
                pesoMatch = !peso.equals("") && (data.getPeso() / 1000) < Long.parseLong(peso);
            } catch (NumberFormatException e) {
                pesoMatch = false;
            }

            return nombreMatch || pesoMatch || categoriaMatch;
        });

        System.out.println(nodes);

        searchViewer.removeAll();
        nodes.forEach(node -> searchViewer.addFile(node.getData().getArchivo(), node.getData().getCarpeta()));

        searchViewer.repaint();
        searchViewer.revalidate();
    }

}
